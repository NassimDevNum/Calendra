<?php
http_response_code(404);
require '../views/header.php';
?>

<h1>Page introuvable</h1>

<?php require '../views/footer.php'; ?>
